import numpy as np


def kinematics_forward(joint1_angle, link1_length, joint2_angle, link2_length):
    position = np.asarray([0, 0, 0])
    orientation = np.asarray([1, 0, 0, 0])
    # 
    
    
    raise NotImplementedError
    # return position, orientation




if __name__ == '__main__':
    # Test your code here
    # Example:
    position, orientation = kinematics_forward(np.pi/2, 1, np.pi/2, 1)
    print(position, orientation)
    